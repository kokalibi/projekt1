export default function Main(){
    return(
        <h2>Welcome to the Bootstrap React App</h2>
    )
}
